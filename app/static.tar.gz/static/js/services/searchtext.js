'use strict';

/**
 * @ngdoc service
 * @name yomantutApp.searchText
 * @description
 * # searchText
 * Service in the yomantutApp.
 */
angular.module('unisalad')
  .service('searchText', function () {
    this.words = '';
  });
