'use strict';

angular.module('unisalad')
  .controller('AboutCtrl', function ($scope) {
  	$scope.pageClass = 'page-about';
  });
