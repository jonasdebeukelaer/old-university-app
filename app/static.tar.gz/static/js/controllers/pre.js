'use strict';

angular.module('unisalad')
  .controller('PreCtrl', function ($scope) {
  });